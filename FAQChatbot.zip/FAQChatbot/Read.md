Installation
1️⃣ Install Dependencies
pip install nltk scikit-learn flask

▶️ Run the Chatbot (Terminal Mode)
python chatbot.py

▶️ Run the Web UI Version
python app.py


Visit:

http://127.0.0.1:5000